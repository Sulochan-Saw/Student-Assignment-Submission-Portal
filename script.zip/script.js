// Listen for the form submission
document.getElementById('assignment-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Stop the form from reloading the page

    // Get the input values from the form
    let name = document.getElementById('student-name').value;
    let enrollment = document.getElementById('enrollment-number').value;
    let title = document.getElementById('assignment-title').value;
    let date = document.getElementById('submission-date').value;
    let file = document.getElementById('assignment-file').files[0];

    // Check if a file was selected
    if (!file) {
        alert("File upload is required!");
        return; // Stop here if no file is uploaded
    }

    // Create a new row for the assignment table
    let row = document.createElement('tr');
    row.innerHTML = `
        <td>${name}</td>
        <td>${enrollment}</td>
        <td>${title}</td>
        <td>${date}</td>
        <td><a href="#" download="${file.name}">Download</a></td>
    `;

    // Add the new row to the table
    document.getElementById('records-body').appendChild(row);

    // Clear the form inputs after submission
    document.getElementById('assignment-form').reset();
});
